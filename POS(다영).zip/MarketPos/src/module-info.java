/**
 * 
 */
/**
 * @author PKNU
 *
 */
module MarketPos {
}