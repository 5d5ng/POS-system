package MarketPos;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.border.Border;


public class GUI_admin extends JFrame{
	public static Scanner scan;//���� �Է��ϴ� ��.
	//	public static DBconnector dbconnecter;//DBconnector class�� ���.
	public static DBconnector dbconnecter = DBconnector.getInstacne();
	private JPanel adPanel;

	private JButton PrecordButton = new JButton(new ImageIcon("images/PrecordButton.jpg")); //��ǰ���
	private JButton PlookupButton = new JButton(new ImageIcon("images/PlookupButton.jpg")); //��ǰ��ȸ
	private JButton PsearchButton = new JButton(new ImageIcon("images/PsearchButton.jpg")); //��ǰ�˻�
	private JButton addPamountButton = new JButton(new ImageIcon("images/addPamountButton.jpg")); //����߰�
	private JButton ClookupButton = new JButton(new ImageIcon("images/ClookupButton.jpg")); //������ȸ
	private JButton CsearchButton = new JButton(new ImageIcon("images/CsearchButton.jpg")); //�����˻�
	private JButton BlookupButton = new JButton(new ImageIcon("images/BlookupButton.jpg")); //�����ȸ
	private JButton exitButton = new JButton(new ImageIcon("images/exitButton.jpg")); //����
	private ImageIcon logo = new ImageIcon("images/logo.jpg");
	private JLabel logoImage = new JLabel(logo);

	public GUI_admin() 
	{
		super("MarketPos");
		scan = new Scanner(System.in);//���� �Է��ϴ� ��ü ����
		//		this.dbconnecter = new DBconnector();

	}
	public void check() {
		JFrame f = new JFrame();
		f.setTitle("������ �α���");
		JPanel NewWindowMember = new JPanel();
		f.setLayout(new BorderLayout());
		NewWindowMember.setLayout(null);
		NewWindowMember.setBackground(new Color(26,44,91));
		f.setContentPane(NewWindowMember);

		ImageIcon password = new ImageIcon("images/password.jpg");
		JLabel passwordImage = new JLabel(password);

		JButton okayButton = new JButton(new ImageIcon("images/okay.jpg")); //����
		setImage(okayButton);

		JPasswordField passwordField = new JPasswordField(); 
		setTextField(passwordField);      

		NewWindowMember.add(passwordImage);
		NewWindowMember.add(passwordField);

		NewWindowMember.add(okayButton);

		passwordImage.setBounds(30,72,150,46);
		passwordField.setBounds(205,72,250,50);

		okayButton.setBounds(180,170,138,51);
		okayButton.addMouseListener(new MouseListener() {
			@Override
			public void mouseEntered(java.awt.event.MouseEvent e) {
				ImageIcon okay_clicked = new ImageIcon("images/okay_clicked.jpg"); //��ǰ���� ������ �̹���
				okayButton.setIcon(okay_clicked);				
			}
			@Override
			public void mouseExited(java.awt.event.MouseEvent e) {
				ImageIcon undo = new ImageIcon("images/okay.jpg"); // ������ �������� �̹��� 
				okayButton.setIcon(undo);

			}
			@Override
			public void mouseClicked(java.awt.event.MouseEvent e) {
			}
			@Override
			public void mousePressed(java.awt.event.MouseEvent e) {
				String PW =passwordField.getText();
				if(dbconnecter.checkPw(PW)) {
					JFrame ad = new JFrame("administrator");
					go(ad);
					f.setVisible(false);
				}
				else {
					System.out.println("�н����尡 ���� �ʽ��ϴ�.");
					JOptionPane popup =new JOptionPane();
					popup.showMessageDialog(null, "��й�ȣ�� Ʋ�Ƚ��ϴ�!");
				}
			}
			@Override
			public void mouseReleased(java.awt.event.MouseEvent e) {

			}	
		});
		f.setSize(500,300);
		f.setResizable(true);
		f.setVisible(true);

	}

	public void go(JFrame ad) {//DBconnector class ����.
		System.out.println("������ ���α׷��� �����մϴ�.");
		AdminMain(ad); //�Ǹ��� �ʱ�ȭ��
		ad.setPreferredSize(new Dimension(1000,750));
		ad.pack();
		ad.setVisible(true);
	}


	public void setTextField(JTextField L){
		Border lineBorder = BorderFactory.createLineBorder(Color.white, 4);
		Border emptyBorder = BorderFactory.createEmptyBorder(7, 7, 7, 7);
		L.setBorder(BorderFactory.createCompoundBorder(lineBorder,emptyBorder));
		L.setBackground(new Color(26,44,91));
		L.setForeground(Color.white);
		L.setFont(new Font("����",Font.PLAIN,25));
	}

	private void setImage(JButton bt) {
		bt.setBackground(Color.red);
		bt.setBorderPainted(false);
		bt.setFocusPainted(false);
		bt.setContentAreaFilled(false);
	}
	public void AdminMain(JFrame ad) 
	{
		adPanel = new JPanel();
		ad.setLayout(new BorderLayout());
		adPanel.setBackground(new Color(26,44,91));
		adPanel.setLayout(null);

		setImage(PrecordButton);
		setImage(PlookupButton);
		setImage(PsearchButton);
		setImage(addPamountButton);
		setImage(ClookupButton);
		setImage(CsearchButton);
		setImage(BlookupButton);
		setImage(exitButton);

		logoImage.setBounds(20,15, 345, 50);     //�ΰ�

		PrecordButton.setBounds(85,150,200,200);    //��ǰ���
		PrecordButton.addMouseListener(new MouseListener() {
			@Override
			public void mouseEntered(java.awt.event.MouseEvent e) {
				ImageIcon PrecordButton_clicked = new ImageIcon("images/PrecordButton_clicked.jpg"); //��ǰ���� ������ �̹���
				PrecordButton.setIcon(PrecordButton_clicked);				
			}
			@Override
			public void mouseExited(java.awt.event.MouseEvent e) {
				ImageIcon undo = new ImageIcon("images/PrecordButton.jpg"); // ������ �������� �̹��� 
				PrecordButton.setIcon(undo);

			}
			@Override
			public void mousePressed(java.awt.event.MouseEvent e) {
				product_add();
			}
			@Override
			public void mouseClicked(java.awt.event.MouseEvent e) {
			}	
			@Override
			public void mouseReleased(java.awt.event.MouseEvent e) {

			}	
		});
		PlookupButton.setBounds(295,150, 200, 200);   //��ǰ��ȸ
		PlookupButton.addMouseListener(new MouseListener() {
			@Override
			public void mouseEntered(java.awt.event.MouseEvent e) {
				ImageIcon PlookupButton_clicked = new ImageIcon("images/PlookupButton_clicked.jpg"); //��ǰ���� ������ �̹���
				PlookupButton.setIcon(PlookupButton_clicked);				
			}
			@Override
			public void mouseExited(java.awt.event.MouseEvent e) {
				ImageIcon undo = new ImageIcon("images/PlookupButton.jpg"); // ������ �������� �̹��� 
				PlookupButton.setIcon(undo);

			}
			@Override
			public void mousePressed(java.awt.event.MouseEvent e) {
				JFrame f = new JFrame("��ǰ��ȸ");
				f.setLocationRelativeTo(null);
				f.setSize(500,500);
				f.setVisible(true);
				ArrayList<String> data = dbconnecter.pdisplay();    
				DefaultListModel<String> m = new DefaultListModel<>();
				for(int i = 0 ;i<data.size();i++) {
					m.addElement(data.get(i)); //����Ʈ ��ü ���
				}
				JList list = new JList(m);     
				f.add(list);			
			}
			@Override
			public void mouseClicked(java.awt.event.MouseEvent e) {
			}	
			@Override
			public void mouseReleased(java.awt.event.MouseEvent e) {

			}	
		});


		PsearchButton.setBounds(495,150, 200, 200);   //��ǰ�˻�
		PsearchButton.addMouseListener(new MouseListener() {
			@Override
			public void mouseEntered(java.awt.event.MouseEvent e) {
				ImageIcon PsearchButton_clicked = new ImageIcon("images/PsearchButton_clicked.jpg"); //��ǰ���� ������ �̹���
				PsearchButton.setIcon(PsearchButton_clicked);				
			}
			@Override
			public void mouseExited(java.awt.event.MouseEvent e) {
				ImageIcon undo = new ImageIcon("images/PsearchButton.jpg"); // ������ �������� �̹��� 
				PsearchButton.setIcon(undo);

			}
			@Override
			public void mousePressed(java.awt.event.MouseEvent e) {
				product_search();
			}
			@Override
			public void mouseClicked(java.awt.event.MouseEvent e) {
			}	
			@Override
			public void mouseReleased(java.awt.event.MouseEvent e) {

			}	
		});
		addPamountButton.setBounds(695,150,200,200);    //����߰�
		addPamountButton.addMouseListener(new MouseListener() {
			@Override
			public void mouseEntered(java.awt.event.MouseEvent e) {
				ImageIcon addPamountButton_clicked = new ImageIcon("images/addPamountButton_clicked.jpg"); //��ǰ���� ������ �̹���
				addPamountButton.setIcon(addPamountButton_clicked);				
			}
			@Override
			public void mouseExited(java.awt.event.MouseEvent e) {
				ImageIcon undo = new ImageIcon("images/addPamountButton.jpg"); // ������ �������� �̹��� 
				addPamountButton.setIcon(undo);

			}
			@Override
			public void mousePressed(java.awt.event.MouseEvent e) {
				product_update();
			}
			@Override
			public void mouseClicked(java.awt.event.MouseEvent e) {
			}	
			@Override
			public void mouseReleased(java.awt.event.MouseEvent e) {

			}	
		});
		ClookupButton.setBounds(85,350,200,200);    //������ȸ
		ClookupButton.addMouseListener(new MouseListener() {
			@Override
			public void mouseEntered(java.awt.event.MouseEvent e) {
				ImageIcon ClookupButton_clicked = new ImageIcon("images/ClookupButton_clicked.jpg"); //��ǰ���� ������ �̹���
				ClookupButton.setIcon(ClookupButton_clicked);				
			}
			@Override
			public void mouseExited(java.awt.event.MouseEvent e) {
				ImageIcon undo = new ImageIcon("images/ClookupButton.jpg"); // ������ �������� �̹��� 
				ClookupButton.setIcon(undo);

			}
			@Override
			public void mousePressed(java.awt.event.MouseEvent e) {
				JFrame f = new JFrame("������ȸ");
				f.setLocationRelativeTo(null);
				f.setSize(500,500);
				f.setVisible(true);
				ArrayList<String> data = dbconnecter.cdisplay();    
				DefaultListModel<String> m = new DefaultListModel<>();
				for(int i = 0 ;i<data.size();i++) {
					m.addElement(data.get(i)); //����Ʈ ��ü ���
				}
				JList list = new JList(m);     
				f.add(list);
			}
			@Override
			public void mouseClicked(java.awt.event.MouseEvent e) {
			}	
			@Override
			public void mouseReleased(java.awt.event.MouseEvent e) {

			}	
		});


		CsearchButton.setBounds(295,350,200,200);   //�����˻�
		CsearchButton.addMouseListener(new MouseListener() {
			@Override
			public void mouseEntered(java.awt.event.MouseEvent e) {
				ImageIcon CsearchButton_clicked = new ImageIcon("images/CsearchButton_clicked.jpg"); //��ǰ���� ������ �̹���
				CsearchButton.setIcon(CsearchButton_clicked);				
			}
			@Override
			public void mouseExited(java.awt.event.MouseEvent e) {
				ImageIcon undo = new ImageIcon("images/CsearchButton.jpg"); // ������ �������� �̹��� 
				CsearchButton.setIcon(undo);

			}
			@Override
			public void mousePressed(java.awt.event.MouseEvent e) {
				customer_search();
			}
			@Override
			public void mouseClicked(java.awt.event.MouseEvent e) {
			}	
			@Override
			public void mouseReleased(java.awt.event.MouseEvent e) {

			}	
		});
		BlookupButton.setBounds(495,350,200,200);   //�����ȸ
		BlookupButton.addMouseListener(new MouseListener() {
			@Override
			public void mouseEntered(java.awt.event.MouseEvent e) {
				ImageIcon BlookupButton_clicked = new ImageIcon("images/BlookupButton_clicked.jpg"); //��ǰ���� ������ �̹���
				BlookupButton.setIcon(BlookupButton_clicked);				
			}
			@Override
			public void mouseExited(java.awt.event.MouseEvent e) {
				ImageIcon undo = new ImageIcon("images/BlookupButton.jpg"); // ������ �������� �̹��� 
				BlookupButton.setIcon(undo);

			}
			@Override
			public void mousePressed(java.awt.event.MouseEvent e) {
				JFrame f = new JFrame("�����ȸ");
				f.setLocationRelativeTo(null);
				f.setSize(500,500);
				f.setVisible(true);
				ArrayList<String> data = dbconnecter.bdisplay();    
				DefaultListModel<String> m = new DefaultListModel<>();
				for(int i = 0 ;i<data.size();i++) {
					m.addElement(data.get(i)); //����Ʈ ��ü ���
				}
				JList list = new JList(m);     
				f.add(list);
			}
			@Override
			public void mouseClicked(java.awt.event.MouseEvent e) {
			}	
			@Override
			public void mouseReleased(java.awt.event.MouseEvent e) {

			}	
		});


		exitButton.setBounds(695,350, 200, 200);    //����
		exitButton.addMouseListener(new MouseListener() {
			@Override
			public void mouseEntered(java.awt.event.MouseEvent e) {
				ImageIcon exitButton_clicked = new ImageIcon("images/exitButton_clicked.jpg"); //��ǰ���� ������ �̹���
				exitButton.setIcon(exitButton_clicked);				
			}
			@Override
			public void mouseExited(java.awt.event.MouseEvent e) {
				ImageIcon undo = new ImageIcon("images/exitButton.jpg"); // ������ �������� �̹��� 
				exitButton.setIcon(undo);

			}
			@Override
			public void mousePressed(java.awt.event.MouseEvent e) {
				ad.setVisible(false);
			}
			@Override
			public void mouseClicked(java.awt.event.MouseEvent e) {
			}	
			@Override
			public void mouseReleased(java.awt.event.MouseEvent e) {

			}	
		});
		adPanel.add(logoImage);
		adPanel.add(PrecordButton);
		adPanel.add(PlookupButton);
		adPanel.add(PsearchButton);
		adPanel.add(addPamountButton);
		adPanel.add(ClookupButton);
		adPanel.add(CsearchButton);
		adPanel.add(BlookupButton);
		adPanel.add(exitButton);
		ad.getContentPane().add(adPanel);
	}

	public void product_add() {

		JFrame padd = new JFrame("��ǰ���");
		JPanel NewWindowMember = new JPanel();
		setLayout(new BorderLayout());
		NewWindowMember.setLayout(null);
		NewWindowMember.setBackground(new Color(26,44,91));
		setContentPane(NewWindowMember);

		ImageIcon barcode = new ImageIcon("images/barcode.jpg");
		JLabel barcodeImage = new JLabel(barcode);
		ImageIcon pname = new ImageIcon("images/pname.jpg");
		JLabel pnameImage = new JLabel(pname);	        
		ImageIcon ptype = new ImageIcon("images/ptype.jpg");
		JLabel ptypeImage = new JLabel(ptype);
		ImageIcon pamount = new ImageIcon("images/amount.jpg");
		JLabel pamountImage = new JLabel(pamount);
		ImageIcon expiration = new ImageIcon("images/expiration.jpg");
		JLabel expirationImage = new JLabel(expiration);	        
		ImageIcon price = new ImageIcon("images/price.jpg");
		JLabel priceImage = new JLabel(price);


		JButton okayButton = new JButton(new ImageIcon("images/okay.jpg")); //Ȯ��
		setImage(okayButton);


		JTextField barcodeField = new JTextField(); 
		setTextField(barcodeField);     
		JTextField pnameField = new JTextField();
		setTextField(pnameField);     
		JTextField ptypeField = new JTextField();
		setTextField(ptypeField);             
		JTextField pamountField = new JTextField(); 
		setTextField(pamountField);     
		JTextField expirationField = new JTextField();
		setTextField(expirationField);     
		JTextField priceField = new JTextField();
		setTextField(priceField);    

		NewWindowMember.add(barcodeImage); //���ڵ�
		NewWindowMember.add(pnameImage);	//��ǰ�̸�
		NewWindowMember.add(ptypeImage);	//��ǰ����
		NewWindowMember.add(pamountImage);	//��ǰ����
		NewWindowMember.add(expirationImage);	//�������
		NewWindowMember.add(priceImage);	//��ǰ����

		NewWindowMember.add(barcodeField);
		NewWindowMember.add(pnameField);
		NewWindowMember.add(ptypeField);
		NewWindowMember.add(pamountField);
		NewWindowMember.add(expirationField);
		NewWindowMember.add(priceField);

		NewWindowMember.add(okayButton);

		barcodeImage.setBounds(55,72,118,46);
		pnameImage.setBounds(38,160,155,47);
		ptypeImage.setBounds(38,245,156,46);
		pamountImage.setBounds(70,335,80,46);
		expirationImage.setBounds(38,425,155,47);
		priceImage.setBounds(70,515,77,42);

		barcodeField.setBounds(205,70,250,50);
		pnameField.setBounds(205,160,250,50);
		ptypeField.setBounds(205,250,250,50);	        
		pamountField.setBounds(205,340,250,50);
		expirationField.setBounds(205,430,250,50);
		priceField.setBounds(205,520,250,50);


		okayButton.setBounds(180,620,138,51);
		okayButton.addMouseListener(new MouseListener() {


			@Override
			public void mouseEntered(java.awt.event.MouseEvent e) {
				ImageIcon okay_clicked = new ImageIcon("images/okay_clicked.jpg"); //��ǰ���� ������ �̹���
				okayButton.setIcon(okay_clicked);				
			}
			@Override
			public void mouseExited(java.awt.event.MouseEvent e) {
				ImageIcon undo = new ImageIcon("images/okay.jpg"); // ������ �������� �̹��� 
				okayButton.setIcon(undo);

			}
			@Override
			public void mouseClicked(java.awt.event.MouseEvent e) {

			}
			@Override
			public void mousePressed(java.awt.event.MouseEvent e) {
				if(barcodeField.getText().equals("") || pnameField.getText().equals("") || ptypeField.getText().equals("") ||
						pamountField.getText().equals("") || expirationField.getText().equals("") || priceField.getText().equals("")) {
					JOptionPane popup = new JOptionPane();
					popup.showMessageDialog(null, "�׸��� ��� �Է��ϼ���");	
				}
				else {
					dbconnecter.addProduct(barcodeField.getText(), pnameField.getText(),ptypeField.getText(), pamountField.getText(), expirationField.getText(),Integer.parseInt(priceField.getText()));//�� ����.
					System.out.println("����� �Ϸ� �Ǿ����ϴ�.");	
					padd.setVisible(false);
				}
			}
			@Override
			public void mouseReleased(java.awt.event.MouseEvent e) {

			}


		});
		padd.add(NewWindowMember);
		padd.setSize(500,750);
		padd.setResizable(true);
		padd.setVisible(true);

	}



	public void product_search() {
		JFrame psearch = new JFrame("��ǰ�˻�");
		JPanel NewWindowMember = new JPanel();


		setLayout(new BorderLayout());
		NewWindowMember.setLayout(null);
		NewWindowMember.setBackground(new Color(26,44,91));
		setContentPane(NewWindowMember);

		ImageIcon barcode = new ImageIcon("images/barcode.jpg");
		JLabel barcodeImage = new JLabel(barcode);

		JButton okayButton = new JButton(new ImageIcon("images/okay.jpg")); //����
		setImage(okayButton);

		JTextField barcodeField = new JTextField(); 
		setTextField(barcodeField);      

		NewWindowMember.add(barcodeImage);
		NewWindowMember.add(barcodeField);

		NewWindowMember.add(okayButton);

		barcodeImage.setBounds(55,72,118,46);
		barcodeField.setBounds(205,72,250,50);

		okayButton.setBounds(180,170,138,51);
		okayButton.addMouseListener(new MouseListener() {
			@Override
			public void mouseEntered(java.awt.event.MouseEvent e) {
				ImageIcon okay_clicked = new ImageIcon("images/okay_clicked.jpg"); //��ǰ���� ������ �̹���
				okayButton.setIcon(okay_clicked);				
			}
			@Override
			public void mouseExited(java.awt.event.MouseEvent e) {
				ImageIcon undo = new ImageIcon("images/okay.jpg"); // ������ �������� �̹��� 
				okayButton.setIcon(undo);

			}
			@Override
			public void mouseClicked(java.awt.event.MouseEvent e) {

			}
			@Override
			public void mousePressed(java.awt.event.MouseEvent e) {
				JFrame result = new JFrame("�˻����");		   
				String data = dbconnecter.psearch(barcodeField.getText());   
				if(!data.equals("no")) {
					System.out.println("��ǰ�� ã�ҽ��ϴ�");
					Label L = new Label(data);
					result.add(L);
					result.setSize(500,300);
					result.setResizable(true);
					result.setVisible(true);

					psearch.setVisible(false);
				}
			}
			@Override
			public void mouseReleased(java.awt.event.MouseEvent e) {

			}	
		});

		psearch.add(NewWindowMember);
		psearch.setSize(500,300);
		psearch.setResizable(true);
		psearch.setVisible(true);
	}



	public void product_update() {
		JFrame pupdate = new JFrame("����߰�");
		JPanel NewWindowMember = new JPanel();
		setLayout(new BorderLayout());
		NewWindowMember.setLayout(null);
		NewWindowMember.setBackground(new Color(26,44,91));
		setContentPane(NewWindowMember);

		ImageIcon barcode = new ImageIcon("images/barcode.jpg");
		JLabel barcodeImage = new JLabel(barcode);

		ImageIcon amount = new ImageIcon("images/amount.jpg");
		JLabel amountImage = new JLabel(amount);

		JButton okayButton = new JButton(new ImageIcon("images/okay.jpg")); //����
		setImage(okayButton);


		JTextField barcodeField = new JTextField(); 
		setTextField(barcodeField);    
		JTextField amountField = new JTextField(); 
		setTextField(amountField);     

		NewWindowMember.add(barcodeImage);
		NewWindowMember.add(amountImage);

		NewWindowMember.add(barcodeField);
		NewWindowMember.add(amountField);

		NewWindowMember.add(okayButton);

		barcodeImage.setBounds(55,72,118,46);
		amountImage.setBounds(70,162,80,46);

		barcodeField.setBounds(205,72,250,50);
		amountField.setBounds(205,162,250,50);

		okayButton.setBounds(180,280,138,51);
		okayButton.addMouseListener(new MouseListener() {
			@Override
			public void mouseEntered(java.awt.event.MouseEvent e) {
				ImageIcon okay_clicked = new ImageIcon("images/okay_clicked.jpg"); //��ǰ���� ������ �̹���
				okayButton.setIcon(okay_clicked);				
			}
			@Override
			public void mouseExited(java.awt.event.MouseEvent e) {
				ImageIcon undo = new ImageIcon("images/okay.jpg"); // ������ �������� �̹��� 
				okayButton.setIcon(undo);

			}
			@Override
			public void mouseClicked(java.awt.event.MouseEvent e) {

			}
			@Override
			public void mousePressed(java.awt.event.MouseEvent e) {
				if(barcodeField.getText().equals("") || amountField.getText().equals("")) {
					JOptionPane popup = new JOptionPane();
					popup.showMessageDialog(null, "�׸��� ��� �Է��ϼ���");	
				}
				else {				
					dbconnecter.update_pamount(barcodeField.getText(), Integer.parseInt(amountField.getText()));
					pupdate.setVisible(false);
				}
			}
			@Override
			public void mouseReleased(java.awt.event.MouseEvent e) {

			}	
		});
		pupdate.add(NewWindowMember);
		pupdate.setSize(500,400);
		pupdate.setResizable(true);
		pupdate.setVisible(true);
	}




	public void customer_search() {
		JFrame csearch = new JFrame("�����˻�");
		JPanel NewWindowMember = new JPanel();
		setLayout(new BorderLayout());
		NewWindowMember.setLayout(null);
		NewWindowMember.setBackground(new Color(26,44,91));
		setContentPane(NewWindowMember);

		ImageIcon name = new ImageIcon("images/phoneNumber.jpg");
		JLabel phoneImage = new JLabel(name);



		JButton okayButton = new JButton(new ImageIcon("images/okay.jpg")); //����
		setImage(okayButton);


		JTextField phoneField = new JTextField(); 
		setTextField(phoneField);    


		NewWindowMember.add(phoneImage);


		NewWindowMember.add(phoneField);


		NewWindowMember.add(okayButton);

		phoneImage.setBounds(15,72,170,46);
		phoneField.setBounds(205,72,250,50);

		okayButton.setBounds(180,280,138,51);
		okayButton.addMouseListener(new MouseListener() {
			@Override
			public void mouseEntered(java.awt.event.MouseEvent e) {
				ImageIcon okay_clicked = new ImageIcon("images/okay_clicked.jpg"); //��ǰ���� ������ �̹���
				okayButton.setIcon(okay_clicked);				
			}
			@Override
			public void mouseExited(java.awt.event.MouseEvent e) {
				ImageIcon undo = new ImageIcon("images/okay.jpg"); // ������ �������� �̹��� 
				okayButton.setIcon(undo);

			}
			@Override
			public void mouseClicked(java.awt.event.MouseEvent e) {

			}
			@Override
			public void mousePressed(java.awt.event.MouseEvent e) {
				JFrame result = new JFrame("�˻����");		   
				String data = dbconnecter.csearch(phoneField.getText());   
				if(!data.equals("no")) {
					System.out.println("ȸ���� ã�ҽ��ϴ�");
					Label L = new Label(data);
					result.add(L);
					result.setSize(500,300);
					result.setResizable(true);
					result.setVisible(true);

					csearch.setVisible(false);
				}
			}
			@Override
			public void mouseReleased(java.awt.event.MouseEvent e) {

			}	
		});	        
		csearch.add(NewWindowMember);
		csearch.setSize(500,400);
		csearch.setResizable(true);
		csearch.setVisible(true);
	}
}


