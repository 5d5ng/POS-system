package MarketPos;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.border.Border;

//import com.sun.glass.events.MouseEvent;


public class GUI_Seller{

	public static DBconnector dbconnecter = DBconnector.getInstacne();//DBconnector class�� ���.
	//	private static ArrayList<String> ShoppingBasket_Barcode = new ArrayList<String>(); //���ڵ� ���� ����Ʈ
	//	private static ArrayList<Integer> ShoppingBasket_Amount = new ArrayList<Integer>(); // ���ž� ���� ����Ʈ
	//	private static ArrayList<String> ShoppingBasket_Pname  = new ArrayList<String>(); // ��ǰ �� ���� ����Ʈ
	//	private String  customerPnum = ""; // ȸ�� ��ȭ��ȣ ����ʶ� �̿�



	private JButton sellButton = new JButton(new ImageIcon("images/sell.jpg")); //��ǰ����
	private JButton memberButton = new JButton(new ImageIcon("images/member.jpg")); //ȸ���߰�
	private JButton adminButton = new JButton(new ImageIcon("images/admin.jpg")); //�����ڸ��
	private JButton exitButton = new JButton(new ImageIcon("images/exit.jpg")); //����


	private ImageIcon logo = new ImageIcon("images/logo.jpg");
	private JLabel logoImage = new JLabel(logo);
	private JPanel thePanel1;


	//	private JButton buyButton = new JButton(new ImageIcon("images/buy.jpg"));
	//	private JButton cancelButton = new JButton(new ImageIcon("images/cancel.jpg"));
	//	private JButton cashButton = new JButton(new ImageIcon("images/cash.jpg"));
	//	private JButton cardButton = new JButton(new ImageIcon("images/card.jpg"));
	////	private JButton baaddButton = new JButton(new ImageIcon("images/baadd.jpg"));
	//	private JButton bafinButton = new JButton(new ImageIcon("images/bafin.jpg"));
	//	private JButton sellexitButton = new JButton(new ImageIcon("images/sellexit.jpg")); //����

	private JPanel thePanel2;

	private ImageIcon order = new ImageIcon("images/order.jpg");
	private JLabel orderImage = new JLabel(order);
	//private ImageIcon baco = new ImageIcon("images/baco.jpg");
	//private JLabel bacoImage = new JLabel(baco);
	private ImageIcon barcode = new ImageIcon("images/barcode.jpg");
	private JLabel barcodeImage = new JLabel(barcode);
	private ImageIcon num = new ImageIcon("images/amount.jpg");
	private JLabel numImage = new JLabel(num);
	//

	public GUI_Seller() 
	{	 JFrame f1 = new JFrame("MarketPos");
	Main(f1); //�Ǹ��� �ʱ�ȭ��
	f1.getContentPane().add(thePanel1);
	f1.setPreferredSize(new Dimension(1000,750));
	f1.pack();
	f1.setVisible(true);
	f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	private void setImage(JButton bt) {
		bt.setBackground(Color.red);
		bt.setBorderPainted(false);
		bt.setFocusPainted(false);
		bt.setContentAreaFilled(false);
	}
	public void Main(JFrame f1) 
	{
		thePanel1 = new JPanel();
		f1.setLayout(new BorderLayout());
		thePanel1.setBackground(new Color(26,44,91));
		thePanel1.setLayout(null);
		setImage(sellButton); //�Ǹ�
		setImage(memberButton); //ȸ���߰� ��ư
		setImage(adminButton); // ������ ��ư
		setImage(exitButton); //���� ��ư 

		logoImage.setBounds(20,15, 345, 50); 

		sellButton.setBounds(250,150, 200, 200);		
		sellButton.addMouseListener(new MouseListener() {
			@Override
			public void mouseEntered(java.awt.event.MouseEvent e) {
				ImageIcon sellButton_clicked = new ImageIcon("images/sell_clicked.jpg"); //��ǰ���� ������ �̹���
				sellButton.setIcon(sellButton_clicked);				
			}
			@Override
			public void mouseExited(java.awt.event.MouseEvent e) {
				ImageIcon undo = new ImageIcon("images/sell.jpg"); // ������ �������� �̹��� 
				sellButton.setIcon(undo);
			}
			@Override
			public void mousePressed(java.awt.event.MouseEvent e) {
				JFrame f2 = new JFrame("��ǰ����");
				purchase(f2);
				f2.setPreferredSize(new Dimension(1000,750));
				f2.pack();
				f2.setVisible(true);			
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub

			}
			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub

			}
		});

		memberButton.setBounds(500,150, 200, 200);
		memberButton.addMouseListener(new MouseListener() {
			@Override
			public void mouseEntered(java.awt.event.MouseEvent e) {
				ImageIcon member_clicked = new ImageIcon("images/member_clicked.jpg"); //��ǰ���� ������ �̹���
				memberButton.setIcon(member_clicked);				
			}
			@Override
			public void mouseExited(java.awt.event.MouseEvent e) {
				ImageIcon undo = new ImageIcon("images/member.jpg"); // ������ �������� �̹��� 
				memberButton.setIcon(undo);

			}
			@Override
			public void mouseClicked(java.awt.event.MouseEvent e) {

			}
			@Override
			public void mousePressed(java.awt.event.MouseEvent e) {
				addMemberWindow();

			}
			@Override
			public void mouseReleased(java.awt.event.MouseEvent e) {

			}	
		});


		adminButton.setBounds(250,400, 200, 200);
		adminButton.addMouseListener(new MouseListener() {
			@Override
			public void mouseEntered(java.awt.event.MouseEvent e) {
				ImageIcon admin_clicked = new ImageIcon("images/admin_clicked.jpg"); //��ǰ���� ������ �̹���
				adminButton.setIcon(admin_clicked);				
			}
			@Override
			public void mouseExited(java.awt.event.MouseEvent e) {
				ImageIcon undo = new ImageIcon("images/admin.jpg"); // ������ �������� �̹��� 
				adminButton.setIcon(undo);

			}
			@Override
			public void mouseClicked(java.awt.event.MouseEvent e) {

			}
			@Override
			public void mousePressed(java.awt.event.MouseEvent e) {
				GUI_admin ad = new GUI_admin();
				ad.check();
			}
			@Override
			public void mouseReleased(java.awt.event.MouseEvent e) {

			}	
		});

		exitButton.setBounds(500,400, 200, 200);
		exitButton.addMouseListener(new MouseListener() {
			@Override
			public void mouseEntered(java.awt.event.MouseEvent e) {
				ImageIcon exit_clicked = new ImageIcon("images/exit_clicked.jpg"); //��ǰ���� ������ �̹���
				exitButton.setIcon(exit_clicked);				
			}
			@Override
			public void mouseExited(java.awt.event.MouseEvent e) {
				ImageIcon undo = new ImageIcon("images/exit.jpg"); // ������ �������� �̹��� 
				exitButton.setIcon(undo);

			}
			@Override
			public void mouseClicked(java.awt.event.MouseEvent e) {
			}
			@Override
			public void mousePressed(java.awt.event.MouseEvent e) {
				System.exit(1);
			}
			@Override
			public void mouseReleased(java.awt.event.MouseEvent e) {

			}	
		});

		thePanel1.add(logoImage);
		thePanel1.add(sellButton);
		thePanel1.add(memberButton);
		thePanel1.add(adminButton);
		thePanel1.add(exitButton);

	}
	public void setTextField(JTextField L){
		Border lineBorder = BorderFactory.createLineBorder(Color.white, 4);
		Border emptyBorder = BorderFactory.createEmptyBorder(7, 7, 7, 7);
		L.setBorder(BorderFactory.createCompoundBorder(lineBorder,emptyBorder));
		L.setBackground(new Color(26,44,91));
		L.setForeground(Color.white);
		L.setFont(new Font("����",Font.PLAIN,25));
	}


	// �ؽ�Ʈ�ʵ� ������ ��� �۲� �Լ�
	public void	addMemberWindow() {
		JFrame f = new JFrame();
		f.setTitle("ȸ���߰�");
		JPanel NewWindowMember = new JPanel();
		f.setLayout(new BorderLayout());
		NewWindowMember.setLayout(null);
		NewWindowMember.setBackground(new Color(26,44,91));
		f.setContentPane(NewWindowMember);

		ImageIcon name = new ImageIcon("images/name.jpg");
		JLabel nameImage = new JLabel(name);
		ImageIcon age = new ImageIcon("images/age.jpg");
		JLabel ageImage = new JLabel(age);	        
		ImageIcon PhoneNumber = new ImageIcon("images/PhoneNumber.jpg");
		JLabel PhoneNumberImage = new JLabel(PhoneNumber);

		JButton okayButton = new JButton(new ImageIcon("images/okay.jpg")); //����
		setImage(okayButton);




		JTextField nameField = new JTextField();  //�̸� �Է�
		setTextField(nameField);     
		JTextField ageField = new JTextField();  //����
		setTextField(ageField);
		JTextField phoneNumberField = new JTextField(); //��ȭ��ȣ
		setTextField(phoneNumberField);     

		NewWindowMember.add(nameImage);
		NewWindowMember.add(ageImage);
		NewWindowMember.add(PhoneNumberImage);
		NewWindowMember.add(nameField);
		NewWindowMember.add(phoneNumberField);
		NewWindowMember.add(ageField);
		NewWindowMember.add(okayButton);

		nameImage.setBounds(55,72,85,46);
		ageImage.setBounds(55,160,81,47);
		PhoneNumberImage.setBounds(13,255,175,44);

		nameField.setBounds(205,70,250,50);
		phoneNumberField.setBounds(205,250,250,50);
		ageField.setBounds(205,160,250,50);
		okayButton.setBounds(170,360,138,51);
		okayButton.addMouseListener(new MouseListener() {
			@Override
			public void mouseEntered(java.awt.event.MouseEvent e) {
				ImageIcon okayButton_clicked = new ImageIcon("images/okay_clicked.jpg"); //������ �̹���
				okayButton.setIcon(okayButton_clicked);				
			}
			@Override
			public void mouseExited(java.awt.event.MouseEvent e) {
				ImageIcon undo = new ImageIcon("images/okay.jpg"); // ������ �������� �̹��� 
				okayButton.setIcon(undo);
			}
			@Override
			public void mousePressed(java.awt.event.MouseEvent e) { //ȸ�����

				if(nameField.getText().equals("") || phoneNumberField.getText().equals("") || ageField.getText().equals("")) {
					JOptionPane popup = new JOptionPane();
					popup.showMessageDialog(null, "�׸��� ��� �Է��ϼ���");	
				}
				else {
					if(!dbconnecter.checkCustomer(phoneNumberField.getText())) { //�̹� ȸ������ ��ϵǾ��������� ���
						dbconnecter.addCustomer(nameField.getText(),phoneNumberField.getText(),'B',0,Integer.parseInt(ageField.getText()));
						System.out.println("ȸ����ϿϷ�");
						JOptionPane popup =new JOptionPane();
						popup.showMessageDialog(null, "ȸ���� ����Ͽ����ϴ�.");
					}
					else {  //ȸ������ ��ϵǾ��ִ� ���
						JOptionPane popup =new JOptionPane();
						popup.showMessageDialog(null, "�̹� ��ϵ� ȸ���Դϴ�.");
					}
					f.setVisible(false);
				}
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub

			}
			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub

			}
		});


		f.setSize(500,500);
		f.setResizable(true);
		f.setVisible(true);


	}

	private void purchase(JFrame f2) {
		JButton baaddButton = new JButton(new ImageIcon("images/baadd.jpg"));

		JButton buyButton = new JButton(new ImageIcon("images/buy.jpg"));
		JButton cancelButton = new JButton(new ImageIcon("images/cancel.jpg"));
		JButton cashButton = new JButton(new ImageIcon("images/cash.jpg"));
		JButton cardButton = new JButton(new ImageIcon("images/card.jpg"));
		//		private JButton baaddButton = new JButton(new ImageIcon("images/baadd.jpg"));
		JButton bafinButton = new JButton(new ImageIcon("images/bafin.jpg"));
		JButton sellexitButton = new JButton(new ImageIcon("images/sellexit.jpg"));

		print_start();
		//		ArrayList<String> ShoppingBasket_Barcode = new ArrayList<String>(); //���ڵ� ���� ����Ʈ
		//		ArrayList<Integer> ShoppingBasket_Amount = new ArrayList<Integer>(); // ���ž� ���� ����Ʈ
		//		ArrayList<String> ShoppingBasket_Pname  = new ArrayList<String>(); // ��ǰ �� ���� ����Ʈ
		//		ArrayList<Integer> ShoppingBasket_Price =  new ArrayList<Integer>();  //��ǰ ����		


		thePanel2 =  new JPanel();
		f2.setLayout(new BorderLayout());
		thePanel2.setBackground(new Color(26,44,91));
		thePanel2.setLayout(null);

		setImage(buyButton);
		setImage(cancelButton);
		setImage(cashButton);
		setImage(cardButton);

		setImage(baaddButton); //���ڵ� �߰� �κ�
		setImage(bafinButton);  // �߰��Ϸ� �κ�
		setImage(sellexitButton);

		logoImage.setBounds(20,15, 345, 50);
		orderImage.setBounds(50, 125, 501, 500);
		//bacoImage.setBounds(600, 125, 315, 207);

		JTextField bacoField = new JTextField(); 
		setTextField(bacoField);
		JTextField numField = new JTextField(); 
		setTextField(numField);

		barcodeImage.setBounds(615, 125, 118, 46);
		numImage.setBounds(615, 180, 80, 46);
		bacoField.setBounds(772, 125, 125, 50);
		numField.setBounds(772, 180, 125, 50);

		JTextArea addProduct = new JTextArea(); 
		JTextArea addPrice = new JTextArea();
		JTextArea addAmount = new JTextArea();
		JTextArea addallPrice = new JTextArea();
		JTextArea allPrice = new JTextArea();

		//���� ��ǰ �߰� �κ�
		baaddButton.setBounds(615, 250, 130, 60);
		baaddButton.addMouseListener(new MouseListener() {
			@Override
			public void mouseEntered(java.awt.event.MouseEvent e) {
				ImageIcon baadd_clicked = new ImageIcon("images/baadd_clicked.jpg"); //��ǰ���� ������ �̹���
				baaddButton.setIcon(baadd_clicked);				
			}
			@Override
			public void mouseExited(java.awt.event.MouseEvent e) {
				ImageIcon undo = new ImageIcon("images/baadd.jpg"); // ������ �������� �̹��� 
				baaddButton.setIcon(undo);

			}
			@Override
			public void mouseClicked(java.awt.event.MouseEvent e) {
			}
			@Override
			public void mousePressed(java.awt.event.MouseEvent e) {
				int onePrice1 = 0;
				Color gray = new Color(0x777777);
				String tmpb = bacoField.getText();
				String tmpnum = numField.getText();

				if(tmpb.equals("") ||tmpnum.equals("")) {

					JOptionPane popup = new JOptionPane();
					popup.showMessageDialog(null, "�׸��� ��� �Է��ϼ���");	

				}
				else {
					String addedBarcode = bacoField.getText();
					int addedAmount = Integer.parseInt(numField.getText());
					int price = dbconnecter.checkProduct(addedBarcode, addedAmount);
					String addedPname = dbconnecter.pnamecalculation(addedBarcode);

					if(price >=1) {
						DBconnector.ShoppingBasket_Barcode.add(addedBarcode); //��ٱ��Ͽ� �߰�
						DBconnector.ShoppingBasket_Amount.add(addedAmount);
						onePrice1 = addProduct(bacoField, numField, addProduct,  addPrice, addAmount, addallPrice);  
						DBconnector.ShoppingBasket_Price.add(price);
						DBconnector.ShoppingBasket_Pname.add(addedPname);  //��ǰ�̸� ��Ƶδ� ��
						System.out.println(addedBarcode+" : "+addedAmount+"��");

					}
					else {
						System.out.println("������ �� ���� ��ǰ�Դϴ�.");
						JOptionPane popup =new JOptionPane();
						popup.showMessageDialog(null, "������ �� ���� ��ǰ�Դϴ�.");	
					}

					int tmp_onePrice2 =0;

					String onePrice2 = allPrice.getText();
					if(onePrice2.equals("")) 
						tmp_onePrice2 =0;
					else 
						tmp_onePrice2 = Integer.parseInt(onePrice2);

					int sumPrice = onePrice1 + tmp_onePrice2;
					allPrice.setText(Integer.toString(sumPrice));
					allPrice.setFont(new Font("����",Font.PLAIN,25));
					allPrice.setForeground(Color.white);
					allPrice.setBackground(gray);
					thePanel2.add(allPrice);
					allPrice.setBounds(455, 587, 70, 30);
				}
			}
			@Override
			public void mouseReleased(java.awt.event.MouseEvent e) {

			}	
		});

		//���� �Ϸ� ��ư �κ� - �߰��Ϸ�
		bafinButton.setBounds(770, 250, 130, 60);
		bafinButton.addMouseListener(new MouseListener() {
			@Override
			public void mouseEntered(java.awt.event.MouseEvent e) {
				ImageIcon bafin_clicked = new ImageIcon("images/bafin_clicked.jpg"); //������ �̹���
				bafinButton.setIcon(bafin_clicked);				
			}
			@Override
			public void mouseExited(java.awt.event.MouseEvent e) {
				ImageIcon undo = new ImageIcon("images/bafin.jpg"); // ������ �������� �̹��� 
				bafinButton.setIcon(undo);
			}
			@Override
			public void mousePressed(java.awt.event.MouseEvent e) { 
				DBconnector.added_all = true;	

				dbconnecter.fee = calculation(DBconnector.ShoppingBasket_Price,DBconnector.ShoppingBasket_Amount);
				JOptionPane popup =new JOptionPane();
				popup.showMessageDialog(null, "��� ��ǰ ���Ϸ� ���� ������ �����մϴ�.");			
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub

			}
			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub

			}
		});



		//ȸ������ �׼Ǻκ�
		buyButton.setBounds(620, 350, 126, 126);
		buyButton.addMouseListener(new MouseListener() {
			@Override
			public void mouseEntered(java.awt.event.MouseEvent e) {
				ImageIcon buy_clicked = new ImageIcon("images/buy_clicked.jpg"); //������ �̹���
				buyButton.setIcon(buy_clicked);				
			}
			@Override
			public void mouseExited(java.awt.event.MouseEvent e) {
				ImageIcon undo = new ImageIcon("images/buy.jpg"); // ������ �������� �̹��� 
				buyButton.setIcon(undo);
			}
			@Override
			public void mousePressed(java.awt.event.MouseEvent e) { 
				if(DBconnector.added_all) {
					JFrame f = new JFrame();
					memberbuy(f);  
				}
				else {
					JOptionPane popup =new JOptionPane();
					popup.showMessageDialog(null, "���ſϷḦ �����ʾҽ��ϴ�.���Ÿ� �Ϸ��Ͽ��ٸ�,�߰��Ϸ� ��ư�� �����ּ���.");					

				}
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub

			}
			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub

			}
		});

		//���� ��ҹ�ư�� ���� ���
		cancelButton.setBounds(770, 350, 126, 126);
		cancelButton.addMouseListener(new MouseListener() {
			@Override
			public void mouseEntered(java.awt.event.MouseEvent e) {
				ImageIcon cancel_clicked = new ImageIcon("images/cancel_clicked.jpg"); //������ �̹���
				cancelButton.setIcon(cancel_clicked);				
			}
			@Override
			public void mouseExited(java.awt.event.MouseEvent e) {
				ImageIcon undo = new ImageIcon("images/cancel.jpg"); // ������ �������� �̹��� 
				cancelButton.setIcon(undo);
			}
			@Override
			public void mousePressed(java.awt.event.MouseEvent e) { 
				reset_var();
				DBconnector.ShoppingBasket_Barcode.clear();//���ڵ� ���� ����Ʈ
				DBconnector.ShoppingBasket_Amount.clear(); // ���ž� ���� ����Ʈ
				DBconnector.ShoppingBasket_Pname.clear();  // ��ǰ �� ���� ����Ʈ
				DBconnector.ShoppingBasket_Price.clear();   //��ǰ ����	
				DBconnector.ShoppingBasket_Barcode = new ArrayList<String>();
				DBconnector.ShoppingBasket_Amount = new ArrayList<Integer>();
				DBconnector.ShoppingBasket_Pname = new ArrayList<String>();  // ��ǰ �� ���� ����Ʈ
				DBconnector.ShoppingBasket_Price = new ArrayList<Integer>();

			}
			@Override
			public void mouseClicked(MouseEvent e) {				
			}
			@Override
			public void mouseReleased(MouseEvent e) {					
				f2.setVisible(false);
				// TODO Auto-generated method stub

			}

		});
		//���� ���� �׼�
		cashButton.setBounds(620, 500, 126, 126);
		cashButton.addMouseListener(new MouseListener() {
			@Override
			public void mouseEntered(java.awt.event.MouseEvent e) {
				ImageIcon cash_clicked = new ImageIcon("images/cash_clicked.jpg"); //������ �̹���
				cashButton.setIcon(cash_clicked);				
			}
			@Override
			public void mouseExited(java.awt.event.MouseEvent e) {
				ImageIcon undo = new ImageIcon("images/cash.jpg"); // ������ �������� �̹��� 
				cashButton.setIcon(undo);
			}
			@Override
			public void mousePressed(java.awt.event.MouseEvent e) { 
				if(DBconnector.added_all) {
					JFrame f3 = new JFrame("���ݰ���");
					addCashWindow(f3,dbconnecter.fee);

					if(dbconnecter.chkCustomer) dbconnecter.membercalculation();
					books_add(DBconnector.ShoppingBasket_Barcode,DBconnector.ShoppingBasket_Amount,DBconnector.ShoppingBasket_Price,DBconnector.ShoppingBasket_Pname,1);
					product_print(DBconnector.ShoppingBasket_Pname,DBconnector.ShoppingBasket_Amount,DBconnector.ShoppingBasket_Price,dbconnecter.fee,1);
					dbconnecter.renew_pamount(DBconnector.ShoppingBasket_Barcode, DBconnector.ShoppingBasket_Amount);
					reset_var();
				}
				else {
					JOptionPane popup =new JOptionPane();
					popup.showMessageDialog(null, "���ſϷḦ �����ʾҽ��ϴ�.���Ÿ� �Ϸ��Ͽ��ٸ�,�߰��Ϸ� ��ư�� �����ּ���.");					

				}
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub

			}
			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub

			}
		});

		//ī����� �׼�
		cardButton.setBounds(770, 500, 126, 126);
		cardButton.addMouseListener(new MouseListener() {
			@Override
			public void mouseEntered(java.awt.event.MouseEvent e) {
				ImageIcon card_clicked = new ImageIcon("images/card_clicked.jpg"); //������ �̹���
				cardButton.setIcon(card_clicked);				
			}
			@Override
			public void mouseExited(java.awt.event.MouseEvent e) {
				ImageIcon undo = new ImageIcon("images/card.jpg"); // ������ �������� �̹��� 
				cardButton.setIcon(undo);
			}
			@Override
			public void mousePressed(java.awt.event.MouseEvent e) { 
				if(DBconnector.added_all) {
					JFrame f3 = new JFrame("ī�����");
					addCardWindow(f3,dbconnecter.fee);   
					if(dbconnecter.chkCustomer) dbconnecter.membercalculation();
					books_add(DBconnector.ShoppingBasket_Barcode,DBconnector.ShoppingBasket_Amount,DBconnector.ShoppingBasket_Price,DBconnector.ShoppingBasket_Pname,1);
					product_print(DBconnector.ShoppingBasket_Pname,DBconnector.ShoppingBasket_Amount,DBconnector.ShoppingBasket_Price,dbconnecter.fee,1);
					dbconnecter.renew_pamount(DBconnector.ShoppingBasket_Barcode, DBconnector.ShoppingBasket_Amount);
					reset_var();
				}
				else {
					JOptionPane popup =new JOptionPane();
					popup.showMessageDialog(null, "���ſϷḦ �����ʾҽ��ϴ�.���Ÿ� �Ϸ��Ͽ��ٸ�,�߰��Ϸ� ��ư�� �����ּ���.");					

				}
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub

			}
			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub

			}
		});
		sellexitButton.setBounds(885,10, 88, 86);
		sellexitButton.addMouseListener(new MouseListener() {
			@Override
			public void mouseEntered(java.awt.event.MouseEvent e) {
				ImageIcon sellexit_clicked = new ImageIcon("images/sellexit_clicked.jpg"); //��ǰ���� ������ �̹���
				sellexitButton.setIcon(sellexit_clicked);				
			}
			@Override
			public void mouseExited(java.awt.event.MouseEvent e) {
				ImageIcon undo = new ImageIcon("images/sellexit.jpg"); // ������ �������� �̹��� 
				sellexitButton.setIcon(undo);
			}
			@Override
			public void mouseClicked(java.awt.event.MouseEvent e) {

			}
			@Override
			public void mousePressed(java.awt.event.MouseEvent e) {
				f2.setVisible(false);
			}
			@Override
			public void mouseReleased(java.awt.event.MouseEvent e) {

			}	
		});

		thePanel2.add(logoImage);
		thePanel2.add(orderImage);
		thePanel2.add(barcodeImage);
		thePanel2.add(numImage);
		thePanel2.add(bacoField);
		thePanel2.add(numField);
		thePanel2.add(baaddButton);
		thePanel2.add(bafinButton);
		thePanel2.add(buyButton);
		thePanel2.add(cancelButton);
		thePanel2.add(cashButton);
		thePanel2.add(cardButton);
		thePanel2.add(sellexitButton);
		f2.getContentPane().add(thePanel2);




	}

	public int addProduct(JTextField bacoField, JTextField numField,JTextArea addProduct, JTextArea addPrice,JTextArea addAmount,JTextArea addallPrice) {

		String addedBarcode = bacoField.getText();
		int addedAmount = Integer.parseInt(numField.getText());
		int price = dbconnecter.checkProduct(addedBarcode, addedAmount);
		String addedPname = dbconnecter.pnamecalculation(addedBarcode);

		Color gray = new Color(0x777777);
		int allPrice = price * addedAmount;

		addProduct.append(addedPname + "\n");
		addProduct.setFont(new Font("����",Font.PLAIN,25));
		addProduct.setForeground(Color.white);
		addProduct.setBackground(gray);
		thePanel2.add(addProduct);
		addProduct.setBounds(110, 220, 70, 350);


		addPrice.append(Integer.toString(price)+"\n");
		addPrice.setFont(new Font("����",Font.PLAIN,25));
		addPrice.setForeground(Color.white);
		addPrice.setBackground(gray);
		thePanel2.add(addPrice);
		addPrice.setBounds(260, 220, 60, 350);

		addAmount.append(Integer.toString(addedAmount)+"\n");
		addAmount.setFont(new Font("����",Font.PLAIN,25));
		addAmount.setForeground(Color.white);
		addAmount.setBackground(gray);
		thePanel2.add(addAmount);
		addAmount.setBounds(380, 220, 60, 350);

		addallPrice.append(Integer.toString(allPrice)+"\n");
		addallPrice.setFont(new Font("����",Font.PLAIN,25));
		addallPrice.setForeground(Color.white);
		addallPrice.setBackground(gray);
		thePanel2.add(addallPrice);
		addallPrice.setBounds(475, 220, 60, 350);

		bacoField.setText(""); //�߰��ϸ� �ؽ�Ʈ clear
		numField.setText("");

		return allPrice;
	}



	// ȸ������â
	public void memberbuy(JFrame f) {
		f.setTitle("ȸ������");
		JPanel NewWindowMember = new JPanel();
		f.setLayout(new BorderLayout());
		NewWindowMember.setLayout(null);
		NewWindowMember.setBackground(new Color(26,44,91));
		f.setContentPane(NewWindowMember);

		ImageIcon PhoneNumber = new ImageIcon("images/PhoneNumber.jpg");
		JLabel PhoneNumberImage = new JLabel(PhoneNumber);

		JButton okayButton = new JButton(new ImageIcon("images/okay.jpg")); //����
		setImage(okayButton);

		JTextField phoneNumberField = new JTextField();
		setTextField(phoneNumberField);

		NewWindowMember.add(PhoneNumberImage);
		NewWindowMember.add(phoneNumberField);
		NewWindowMember.add(okayButton);

		PhoneNumberImage.setBounds(20,50,175,44);
		phoneNumberField.setBounds(215,50,250,50);

		okayButton.setBounds(180,125,138,51);
		okayButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				if(dbconnecter.checkCustomer(phoneNumberField.getText()))//ȸ���̶��
				{
					System.out.println(phoneNumberField.getText());
					dbconnecter.chkCustomer = true; 
					dbconnecter.phone = phoneNumberField.getText();
					JOptionPane popup =new JOptionPane();
					popup.showMessageDialog(null, "ȸ�� �����Ϸ�.");
				}
				else checkRegister();

				f.setVisible(false);
			}
		});

		f.setSize(500,250);
		f.setResizable(true);
		f.setVisible(true);

	}

	private void checkRegister() {

		int result = JOptionPane.showConfirmDialog(null, "ȸ���� �ƴմϴ�. ȸ���߰��� �Ͻðڽ��ϱ�?","Confirm",JOptionPane.YES_NO_OPTION);
		if(result == JOptionPane.CANCEL_OPTION) {
			return;
		}
		else if(result == JOptionPane.YES_OPTION) {
			addMemberWindow();
			JOptionPane popup =new JOptionPane();
			popup.showMessageDialog(null, "ȸ���߰��� �ϼ����� ȸ�����Ÿ� �ٽ� �����ּ���.");
			//			dbconnecter.chkCustomer = true; 
		}
		else {
			return;
		}
	}




	public void	addCashWindow(JFrame f,int pay) {
		f.setTitle("���ݰ���");
		JPanel NewWindowMember = new JPanel();
		f.setLayout(new BorderLayout());
		NewWindowMember.setLayout(null);
		NewWindowMember.setBackground(new Color(26,44,91));
		f.setContentPane(NewWindowMember);

		ImageIcon InputCash = new ImageIcon("images/getCash.jpg");
		JLabel InputCashImage = new JLabel(InputCash);
		JButton okayButton = new JButton(new ImageIcon("images/okay.jpg")); //����
		setImage(okayButton);

		JTextField InputCashField = new JTextField();
		setTextField(InputCashField);



		NewWindowMember.add(InputCashImage);
		NewWindowMember.add(InputCashField);
		NewWindowMember.add(okayButton);

		InputCashImage.setBounds(20,50,142,41);
		InputCashField.setBounds(215,50,250,50);

		//��Ű ��ư �׼�
		okayButton.setBounds(180,125,138,51);
		okayButton.addMouseListener(new MouseListener() {
			@Override
			public void mouseEntered(java.awt.event.MouseEvent e) {
				ImageIcon okayButton_clicked = new ImageIcon("images/okay_clicked.jpg"); //������ �̹���
				okayButton.setIcon(okayButton_clicked);				
			}
			@Override
			public void mouseExited(java.awt.event.MouseEvent e) {
				ImageIcon undo = new ImageIcon("images/okay.jpg"); // ������ �������� �̹��� 
				okayButton.setIcon(undo);
			}
			@Override
			public void mousePressed(java.awt.event.MouseEvent e) { 
				int InputCash = Integer.parseInt(InputCashField.getText()); // ���� �ݾ�
				if(InputCash>pay) { 
					JOptionPane popup =new JOptionPane();
					int change = InputCash - pay;
					popup.showMessageDialog(null,  "�ѱݾ�:" + pay +"��\r\n" + "������ :" + InputCash+"��\r\n" +"�Ž����� :" + change+"��\r\n" );
					f.setVisible(false);
					print_finish();
				}
				else { // ���� �ݾ��� ���� ���
					JOptionPane popup =new JOptionPane();
					popup.showMessageDialog(null, "�����ݾ��� �����մϴ�.");	
				}

			}
			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub

			}
			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub

			}
		});

		f.setSize(500,250);
		f.setResizable(true);
		f.setVisible(true);
	}

	public void	addCardWindow(JFrame f,int pay) {
		f.setTitle("ī�����");
		JPanel NewWindowMember = new JPanel();
		f.setLayout(new BorderLayout());
		NewWindowMember.setLayout(null);
		NewWindowMember.setBackground(new Color(26,44,91));
		f.setContentPane(NewWindowMember);

		ImageIcon CardNum = new ImageIcon("images/cardNum.jpg");
		JLabel CardNumImage = new JLabel(CardNum);

		JButton okayButton = new JButton(new ImageIcon("images/okay.jpg")); //����
		setImage(okayButton);

		JTextField CardNumField = new JTextField();
		setTextField(CardNumField);

		NewWindowMember.add(CardNumImage);
		NewWindowMember.add(CardNumField);
		NewWindowMember.add(okayButton);

		CardNumImage.setBounds(20,50,142,37);
		CardNumField.setBounds(215,50,250,50);

		okayButton.setBounds(180,125,138,51);
		okayButton.addMouseListener(new MouseListener() {
			@Override
			public void mouseEntered(java.awt.event.MouseEvent e) {
				ImageIcon okayButton_clicked = new ImageIcon("images/okay_clicked.jpg"); //������ �̹���
				okayButton.setIcon(okayButton_clicked);				
			}
			@Override
			public void mouseExited(java.awt.event.MouseEvent e) {
				ImageIcon undo = new ImageIcon("images/okay.jpg"); // ������ �������� �̹��� 
				okayButton.setIcon(undo);
			}
			@Override
			public void mousePressed(java.awt.event.MouseEvent e) { 
				String inputCarNum = CardNumField.getText();

				JOptionPane popup =new JOptionPane();
				popup.showMessageDialog(null, "ī�� �����Ϸ� �����ݾ�:"+pay);	

				f.setVisible(false);
				print_finish();


			}
			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub

			}
			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub

			}
		});
		f.setSize(500,250);
		f.setResizable(true);
		f.setVisible(true);
	}
	//fee�� ����ϴ� �޼ҵ�
	public int calculation(ArrayList<Integer> prod_count_price,ArrayList<Integer> count_list) {	//��ǰ ��ȣ,��ǰ ������ �̿��ؼ� ����� Ȯ�� 
		int fee =0;

		for (int i = 0; i < count_list.size(); i++) {
			fee += prod_count_price.get(i)
					* count_list.get(i);
		}

		System.out.println(count_list.size() + "��/ �� �ݾ� ���Ϸ� =" + fee);// ���Թ�ǰ�� ����, �� �ݾ� ���
		return fee; //�ѱݾ� ȣ��
	}

	private void books_add(ArrayList<String> item_list,ArrayList<Integer> count_list,ArrayList<Integer> shoppingBasket_Price,ArrayList<String> pname_list,int cash) {
		for(int i = 0;i<item_list.size();i++) {
			if(cash != 0)
				dbconnecter.addBooks(item_list.get(i), count_list.get(i), shoppingBasket_Price.get(i), pname_list.get(i),"cash");//�� ����.
			else dbconnecter.addBooks(item_list.get(i), count_list.get(i), shoppingBasket_Price.get(i), pname_list.get(i),"card");
		}
		System.out.println("��� ����� �Ϸ�Ǿ����ϴ�.");

	}



	//	public int payment(JTextField Field) {
	//		String inputCarNum = Field.getText();
	//		ArrayList<Integer> price_list_per1 = dbconnecter.pricecalculation(ShoppingBasket_Barcode); //��ٱ��Ͽ� ���� ��ǰ���� ��ǰ 1���� ���� ����		 
	//		int wholePrice = 0; // �� �����ؾ��ϴ� �ݾ�
	//		for(int i=0 ; i<ShoppingBasket_Amount.size();i++) {
	//			wholePrice += ShoppingBasket_Amount.get(i)*price_list_per1.get(i);
	//
	//		}
	//		return wholePrice;
	//	}
	//
	//	
	public void reset_var() {
		dbconnecter.added_all = false;
		dbconnecter.chkCustomer = false; 
		dbconnecter.fee=0;
		dbconnecter.phone = null;

		//�׸��� Purchase Order�� �����ִ� ���� ������������ �ƴϸ� �ٽ� �ʱ�ȭ������ ���ư����� -������-

	}


	//�������� �ۼ��ϴ� �޼ҵ�
	private void product_print(ArrayList<String> pname_list, ArrayList<Integer> count_list,ArrayList<Integer> price_list, int fee, int cash) {
		BufferedWriter bw;//����
		BufferedReader br;//�б�

		try {


			bw = new BufferedWriter(new FileWriter("receipt.txt", true));
			bw.write("=======================\r\n");
			bw.write("��ǰ�̸�\t\t��ǰ��\t����\r\n");
			bw.write("------------------------------------------");
			bw.newLine();
			for(int i = 0;i<pname_list.size();i++) {
				String data = pname_list.get(i)+"\t\t"+ count_list.get(i)+"\t"+ (count_list.get(i)*price_list.get(i))+ "\n";
				System.out.println("���ҿ� :"+pname_list.size());
				bw.write(data.toString());
				bw.newLine();
			}
			String method;
			if(cash != 0) method="cash";
			else method="card";
			bw.write("------------------------------------------\r\n");
			bw.write("\n");
			bw.write("���� ���\t"+ method);
			bw.newLine();
			bw.write("��    �ݾ�\t"+ fee);
			bw.write("\r\n=======================");
			bw.newLine();
			bw.flush();
			bw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void print_finish() {

		try {
			Desktop.getDesktop().edit(new File("receipt.txt"));
		} catch (IOException e) {
			System.out.println("�������� �����ϴ�.");
			e.printStackTrace();
		}
		System.out.println("�������� ����Ͽ����ϴ�.");
	}

	private void print_start() { 
		try {
			BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter("receipt.txt"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}