package MarketPos;

import MarketPos.GUI_Seller;



public class MainPOS {
	public static void main(String[] args) {
		GUI_Seller frame = new GUI_Seller();
//		frame.Main();
//		SellerProgram seller = new SellerProgram();
//		seller.go();
		
	}
}
 